#!/bin/bash
echo "Running BeforeInstall: cleaning old deployment files..."
rm -rf /home/ec2-user/backend/*
