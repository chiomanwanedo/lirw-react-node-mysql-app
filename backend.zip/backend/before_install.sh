#!/bin/bash
echo "Running BEFORE INSTALL" >> /home/ec2-user/before_install.log
echo "Current working directory: $(pwd)" >> /home/ec2-user/before_install.log
echo "Contents:" >> /home/ec2-user/before_install.log
ls -la >> /home/ec2-user/before_install.log
