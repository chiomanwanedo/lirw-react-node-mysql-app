#!/bin/bash
cd /home/ec2-user/frontend
sudo npm install
