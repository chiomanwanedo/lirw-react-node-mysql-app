#!/bin/bash
# Restart nginx to serve the latest frontend build
sudo systemctl restart nginx
